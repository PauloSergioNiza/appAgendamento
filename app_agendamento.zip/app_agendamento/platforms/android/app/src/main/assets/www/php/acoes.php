<?php

include 'conectar.php';

if ($_POST) {
    print_r($_POST);

    if ($_POST['acao'] == 'inserir') {
        $inserir = "insert into clientes (nome_cliente, dataContato_cliente, origem_cliente, telefone_cliente,descricao_cliente) values ('".$_POST['nome']."','".$_POST['dataContato']."','".$_POST['origem']."','".$_POST['telefone']."','".$_POST['observacao']."')";
        mysqli_query($con, $inserir);
    }

    if ($_POST['acao'] == 'excluir') {
        $deletar = "delete from clientes where id_cliente = '".$_POST['id']."'";
        mysqli_query($con, $deletar);
    }

    if ($_POST['acao'] == 'editar') {
        $deletar = "update clientes set nome_cliente='".$_POST['nome']."',dataContato_cliente='".$_POST['origem']."',origem_cliente='".$_POST['origem']."',telefone_cliente='".$_POST['telefone']."',descricao_cliente='".$_POST['observacao']."' where id_cliente = '".$_POST['id']."'";
        mysqli_query($con, $deletar);
    }

}
    

?>