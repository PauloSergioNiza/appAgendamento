// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
var firebaseConfig = {
	apiKey: "AIzaSyBmRn1YF2O-Z8r1ryyJ1R_KPAH3exnWxPo",
    authDomain: "cordova-app-1bf1d.firebaseapp.com",
    projectId: "cordova-app-1bf1d",
    storageBucket: "cordova-app-1bf1d.appspot.com",
    messagingSenderId: "423392315250",
    appId: "1:423392315250:web:3fa9a0e3a679c7ec797feb",
    measurementId: "G-V2X12V51S1"
 };
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();